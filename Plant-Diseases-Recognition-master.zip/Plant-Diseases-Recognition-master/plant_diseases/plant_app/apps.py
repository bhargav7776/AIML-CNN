from django.apps import AppConfig


class PlantAppConfig(AppConfig):
    name = 'plant_app'
