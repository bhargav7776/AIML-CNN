from django.apps import AppConfig


class PlantApiConfig(AppConfig):
    name = 'plant_api'
